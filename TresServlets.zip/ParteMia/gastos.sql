drop database if exists gastos;
create database gastos;
use gastos;

drop table if exists gastos;
create table gastos(
idGasto int not null primary key,
nombreG nvarchar(50) not null,
servicio nvarchar(50) not null,
prestador nvarchar(50) not null,
fechaG nvarchar(50) not null, 
cantidad float not null
);
 
 drop procedure if exists spInsertaGasto;
 delimiter $$
 create procedure spInsertaGasto(
 in nombre nvarchar(50),
in service nvarchar(50),
in presta nvarchar(50),
in fecha nvarchar(50), 
in cantidad float) 
begin

declare ec int;
declare idG int;
declare mensaje nvarchar(100);

set ec =(select count(*)from gastos where nombreG = nombre);
if (ec = 0) then
		set idG = (select ifnull(max(idGasto), 0) + 1 from gastos);
        insert into gastos(idGasto, nombreG, servicio, prestador, fechaG, cantidad)
				values(idG, nombre, service, presta , fecha, cantidad);
		set mensaje = 'Gasto insertado';
else 
         set idG = -1;
         set mensaje = 'Gasto ya ingresado';
end if;
      select * from gastos;
   end; $$

  
drop procedure if exists spGraficaServicio;
delimiter ** 
create procedure spGraficaServicio()

begin
select count(*) as total, servicio, 
 case 
		when (count(*)>1 and count(*)<5) then '00ffaa' 			
		when (count(*)>5 and count(*)<10) then 'b012fa' 
		when (count(*)>10 and count(*)<50) then 'd35400' 
		else 'ccbb55'  end
		as color 
from gastos 
	group by servicio;
end; **
delimiter ;

drop procedure if exists spGraficaCantidad;
delimiter //
create procedure spGraficaCantidad()

begin
select sum(cantidad) as total, cantidad, servicio,
 case 
		when (sum(cantidad)>10 and sum(cantidad)<500) then '00ffaa' 			
		when (sum(cantidad)>500 and sum(cantidad)<1000) then 'daea31' 
		when (sum(cantidad)>1000 and sum(cantidad)<5000) then '45ed36' 
		else 'ccbb55'  end
		as color 
from gastos 
	group by servicio;
end; //
delimiter ;
            
 select sum(cantidad) from gastos where servicio = 'tramite';
   
   
drop procedure if exists spGraficaPresta;
delimiter //
create procedure spGraficaPresta()

begin
select count(*) as total, prestador,
 case 
		when (count(*)>1 and count(*)<5) then 'a0ffaa' 			
		when (count(*)>5 and count(*)<10) then 'daea31' 
		when (count(*)>10 and count(*)<50) then '45ed36' 
		else 'ccbb55'  end
		as color 
from gastos 
	group by prestador;
end; //
delimiter ;

